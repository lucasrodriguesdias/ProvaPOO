package provaDePOO;

public class main {
    public static void main(String[] args) {
        Fornecedor forn1 = new Fornecedor();
        Produto prod1 = new Produto();
        Produto prod2 = new Produto();

        forn1.setId(1);
        forn1.setNome("Fornecedor Hum");
        forn1.setCnpj("12.345.678/0001-00");
        forn1.setTelefone("3210-2500");

        prod1.setId(1);
        prod1.setNome("Água de coco");
        prod1.setDescricao("Comida");
        prod1.setPrecoCompra(1.50);
        prod1.setPrecoVenda(3.00);
        prod1.setDesconto(0.50);
        prod1.setFabricante("Agua boa");

        prod2.setId(2);
        prod2.setNome("Coxinha");
        prod2.setDescricao("Comida");
        prod2.setPrecoCompra(1.50);
        prod2.setPrecoVenda(5.00);
        prod2.setDesconto(1.50);
        prod2.setFabricante("Salgados Mais");

        System.out.println("Produto 1:");
        System.out.println("ID:" +prod1.getId());
        System.out.println("Nome:" +prod1.getNome());
        System.out.println("Desconto:" +prod1.getDescricao());
        System.out.println("Preço de compra: " +prod1.getPrecoCompra());
        System.out.println("Preço de venda: " +prod1.getPrecoVenda());
        System.out.println("Desconto: " +prod1.getDesconto());
        System.out.println("Fabricante: " +prod1.getFabricante());

    }
}
